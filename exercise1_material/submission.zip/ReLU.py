import numpy as np
from Layers.Base import BaseLayer


class ReLU(BaseLayer):
    def __init__(self):
        super().__init__()
        self.input_tensor = None  # 用于保存前向传播的输入

    def forward(self, input_tensor):

        # 保存输入 tensor，因为 backward 计算需要用到它来判断哪些位置大于 0
        self.input_tensor = input_tensor

        # ReLU: f(x) = max(0, x)
        ReLU = np.maximum(0, input_tensor)
        return ReLU

    def backward(self, error_tensor):
        """
        :param error_tensor: 从下一层传回来的误差梯度
        :return: 传给上一层的误差梯度
        """

        # 创建一个用于传递给上一层的梯度 tensor，初始化为 error_tensor
        gradient_input = error_tensor.copy()

        # Compute gradient: derivative of ReLU is 1 where input > 0, else 0
        # if input_tensor <= 0 , then gradient = 0
        gradient_input = np.where(self.input_tensor > 0, gradient_input, 0)

        return gradient_input
