import copy


class NeuralNetwork:
    def __init__(self, optimizer):
        """
        神经网络构造函数
        :param optimizer: 全局优化器模板 (如 Sgd 对象)
        """
        # 1. An optimizer object received upon construction as the First argument.
        self.optimizer = optimizer

        # 2. A list loss which will contain the loss value for each iteration after calling train.
        self.loss = []

        """
        3. calling train. A list layers which will hold the architecture, a member data  layer, which
        will provide input data and labels and a member loss  layer referring to the special layer
        providing loss and prediction.
        """
        self.layers = []

        # 4.
        self.data_layer = None

        # 5. CrossEntropyLoss
        self.loss_layer = None

    def forward(self):
        #  the data layer provides an input tensor and a label tensor upon calling next() on it.
        self.input_tensor, self.label_tensor = self.data_layer.next()

        self._current_label_tensor = self.label_tensor

        current_tensor = self.input_tensor

        # Forward propagate through all layers in the network
        for layer in self.layers:
            current_tensor = layer.forward(current_tensor)

        loss_val = self.loss_layer.forward(current_tensor, self.label_tensor)
        return loss_val

    def backward(self):
        """
        反向传播流程
        """
        label_tensor = self._current_label_tensor

        # Loss 层反向传播，获取初始误差
        error_tensor = self.loss_layer.backward(label_tensor)

        # 3. 逐层反向传播 (从后往前遍历 layers)
        # reversed(self.layers) 反转列表
        for layer in reversed(self.layers):
            error_tensor = layer.backward(error_tensor)

    def append_layer(self, layer):
        """
        向网络添加层
        :param layer: 要添加的层对象
        """
        # 如果层是可训练的 (trainable)，需要给它分配一个独立的优化器
        if layer.trainable:
            # 使用 deepcopy 复制优化器，确保每层互不干扰
            layer.optimizer = copy.deepcopy(self.optimizer)

        # 将层加入列表
        self.layers.append(layer)

    def train(self, iterations):
        # Training loop
        for i in range(iterations):
            # Forward pass
            loss_value = self.forward()

            # Store loss
            self.loss.append(loss_value)

            # Backward pass
            self.backward()

    def test(self, input_tensor):
        """
        :param input_tensor: 输入数据
        :return: 网络的预测结果
        """
        # 只需要前向传播通过所有普通层 (不包括 loss_layer)
        output = input_tensor
        for layer in self.layers:
            output = layer.forward(output)

        return output


