import numpy as np
from Layers.Base import BaseLayer


class FullyConnected(BaseLayer):
    def __init__(self, input_size, output_size):
        """
        全连接层构造函数
        :param input_size: 输入特征的数量
        :param output_size: 输出特征的数量
        """
        # 1. First,  call  its  super-constructor.
        super().__init__()

        # 2. Set  the  inherited  member  trainable  to  True,  as  this layer  has  trainable  parameters.
        self.trainable = True

        # 3. Initialize weights uniformly random in [0, 1)
        # Shape: [input_size + 1, output_size] where +1 is for bias
        # 额外的一行用于处理 Bias
        self.weights = np.random.uniform(0, 1, (input_size + 1, output_size))

        # 初始化内部变量
        self._optimizer = None
        self.input_tensor = None  # 用于存储前向传播的输入（含 Bias）
        self._gradient_weights = None  # 用于存储计算出的梯度

    def forward(self, input_tensor):
        """
        前向传播: Y = X * W
        """
        # 获取 batch_size
        batch_size = input_tensor.shape[0]

        # input_tensor shape: (batch_size, input_size) -> (batch_size, input_size + 1)
        bias_column = np.ones((batch_size, 1))

        # Add bias column (column of ones) to input_tensor 在输入矩阵右侧拼接一列全 1
        self.input_tensor = np.concatenate((input_tensor, bias_column), axis=1)

        # returns a tensor that serves as the input  tensor  for  the  next  layer.
        # 矩阵乘法计算输出
        output_tensor = np.dot(self.input_tensor, self.weights)

        return output_tensor

    # Add a setter and getter property optimizer which sets and returns the protected member optimizer for this layer.
    @property
    def optimizer(self):
        """ Optimizer 的 Getter """
        return self._optimizer

    @optimizer.setter
    def optimizer(self, optimizer):
        """ Optimizer 的 Setter """
        self._optimizer = optimizer

    def backward(self, error_tensor):
        """
        :param error_tensor: 下一层传回来的误差梯度 (batch_size, output_size)
        :return: 传给上一层的误差梯度 (batch_size, input_size)
        """
        # 1. Compute gradient of weights(dL/dW)
        # Function: Gradient = Input.T * Error
        self._gradient_weights = np.dot(self.input_tensor.T, error_tensor)

        # 2. Compute gradient of input(dL/dX 计算关于输入的误差梯度)
        # Function: Error_prev = Error * Weights.T
        pre_layer_error_tensor = np.dot(error_tensor, self.weights.T)

        # 3. Update weights if optimizer is set
        if self._optimizer is not None:
            self.weights = self._optimizer.calculate_update(self.weights, self._gradient_weights)

        # 4. returns a tensor that serves as the error tensor for the previous layer.
        # 注意：prev_error_tensor 包含了 Bias 的梯度（最后一列），
        # last layer doesn't need gradient of Bias（因为 Bias 是我们这一层加进去的常数 1），所以要把最后一列切掉。
        return pre_layer_error_tensor[:, :-1]

    @property
    def gradient_weights(self):
        """
        For  future  reasons  provide  a  property  gradient  weights  which  returns  the  gradient  with  respect  to  the  weights,  after  they  have
        been calculated in the backward-pass.  These properties are accessed by the unit tests
        and are therefore also important to pass the tests!
        """
        return self._gradient_weights


