import numpy as np


class CrossEntropyLoss:
    def __init__(self):

        self.prediction_tensor = None  # 用于存储输入的预测值 (Y_hat)

    def forward(self, prediction_tensor, label_tensor):
        """
        computes the Loss value according the CrossEntropy Loss formula
        accumulated over the batch.

        :param prediction_tensor: 网络输出的预测概率 (batch_size, num_classes)
        :param label_tensor: 真实标签 (batch_size, num_classes) - One-hot 编码
        :return: 一个标量 Loss 值 (所有样本 Loss 的和)
        """
        # 1. Store prediction tensor for backward pass
        self.prediction_tensor = prediction_tensor

        # 2. Add small epsilon for numerical stability to avoid log(0)
        eps = np.finfo(float).eps  # approximately 2.22e-16

        # 3.Compute cross-entropy loss: -sum(y * log(p)) / batch_size
        loss = -np.sum(label_tensor * np.log(prediction_tensor + eps))

        return loss

    def backward(self, label_tensor):
        """
        反向传播: 计算 Loss 对输入的梯度
        :param label_tensor: 真实标签
        :return: 传给上一层 (通常是 SoftMax) 的 error_tensor
        """
        # Gradient of cross-entropy loss w.r.t. predictions (combined with softmax):
        # dL/dx = (predictions - labels) / batch_size

        eps = np.finfo(float).eps

        error_tensor = - (label_tensor / (self.prediction_tensor + eps))

        return error_tensor
