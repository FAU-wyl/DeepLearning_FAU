import numpy as np
import copy
from Layers.Base import BaseLayer
from Layers.FullyConnected import FullyConnected
from Layers.TanH import TanH


class RNN(BaseLayer):
    def __init__(self, input_size, hidden_size, output_size):
        # 1. 先定义子层
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size

        self.fc_h = FullyConnected(hidden_size + input_size, hidden_size)
        self.fc_y = FullyConnected(hidden_size, output_size)
        self.tanh = TanH()

        # 2. 调用父类初始化
        super().__init__()

        self.trainable = True
        self.memorize = False
        self.h_prev = None

        # BPTT 缓存
        self.input_stack = []
        self.fc_h_layers = []
        self.tanh_layers = []
        self.fc_y_layers = []

    # --- 属性访问器 (修复关键) ---

    @property
    def weights(self):
        return self.fc_h.weights

    @weights.setter
    def weights(self, value):
        # 确保这里能正确修改 fc_h 的权重
        if isinstance(value, np.ndarray) and value.size > 0:
            self.fc_h.weights = value

    @property
    def gradient_weights(self):
        return self.fc_h.gradient_weights

    @gradient_weights.setter
    def gradient_weights(self, value):
        self.fc_h.gradient_weights = value

    @property
    def optimizer(self):
        return self.fc_h.optimizer

    @optimizer.setter
    def optimizer(self, opt):
        # 使用 copy.deepcopy 确保每个子层有独立的优化器状态（特别是 Adam 的 m, v）
        self.fc_h.optimizer = copy.deepcopy(opt)
        self.fc_y.optimizer = copy.deepcopy(opt)

    # --- Forward 与 Backward 逻辑 ---

    def forward(self, input_tensor):
        T = input_tensor.shape[0]
        if not self.memorize or self.h_prev is None:
            self.h_t = np.zeros((1, self.hidden_size))
        else:
            self.h_t = self.h_prev

        output = np.zeros((T, self.output_size))
        self.input_stack = []
        self.fc_h_layers = []
        self.tanh_layers = []
        self.fc_y_layers = []

        for t in range(T):
            x_t = input_tensor[t:t + 1, :]
            combined = np.concatenate((self.h_t, x_t), axis=1)
            self.input_stack.append(combined)

            # 这里的关键是：forward 会改变层的内部状态，所以必须先存快照再 forward
            # 或者 forward 后立即 deepcopy
            h_linear = self.fc_h.forward(combined)
            self.h_t = self.tanh.forward(h_linear)
            y_t = self.fc_y.forward(self.h_t)

            output[t] = y_t

            # 保存快照用于反向传播
            self.fc_h_layers.append(copy.deepcopy(self.fc_h))
            self.tanh_layers.append(copy.deepcopy(self.tanh))
            self.fc_y_layers.append(copy.deepcopy(self.fc_y))

        self.h_prev = self.h_t
        return output

    def backward(self, error_tensor):
        T = error_tensor.shape[0]
        grad_input = np.zeros((T, self.input_size))
        grad_h_next = np.zeros((1, self.hidden_size))

        # 初始化梯度累积量，形状必须与权重一致
        self.gradient_weights_fc_h = np.zeros_like(self.fc_h.weights)
        self.gradient_weights_fc_y = np.zeros_like(self.fc_y.weights)

        for t in reversed(range(T)):
            # 1. 输出层
            grad_h_from_output = self.fc_y_layers[t].backward(error_tensor[t:t + 1, :])
            grad_h_total = grad_h_from_output + grad_h_next

            # 2. 激活层与隐藏层
            grad_tanh = self.tanh_layers[t].backward(grad_h_total)
            grad_combined = self.fc_h_layers[t].backward(grad_tanh)

            # 3. 分离梯度
            grad_h_next = grad_combined[:, :self.hidden_size]
            grad_input[t] = grad_combined[:, self.hidden_size:]

            # 4. 累积梯度
            self.gradient_weights_fc_h += self.fc_h_layers[t].gradient_weights
            self.gradient_weights_fc_y += self.fc_y_layers[t].gradient_weights

        # 更新最终梯度
        self.fc_h.gradient_weights = self.gradient_weights_fc_h
        self.fc_y.gradient_weights = self.gradient_weights_fc_y

        if self.fc_h.optimizer:
            self.fc_h.weights = self.fc_h.optimizer.calculate_update(self.fc_h.weights, self.fc_h.gradient_weights)
        if self.fc_y.optimizer:
            self.fc_y.weights = self.fc_y.optimizer.calculate_update(self.fc_y.weights, self.fc_y.gradient_weights)
        return grad_input

    def initialize(self, weights_initializer, bias_initializer):
        self.fc_h.initialize(weights_initializer, bias_initializer)
        self.fc_y.initialize(weights_initializer, bias_initializer)