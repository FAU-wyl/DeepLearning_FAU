import numpy as np

from Layers.Base import BaseLayer


class Dropout(BaseLayer):

    def __init__(self, probability):
        """

        Implement the constructor for this layer receiving the argument probability determining
    the fraction units to keep.

        :param probability:
        """
        super().__init__()
        self.probability = probability
        self.mask = None  # 用于存储训练时的随机掩码，供 backward 使用

    @property
    def phase(self):
        return 'test' if self.testing_phase else 'train'

    @phase.setter
    def phase(self, value):
        if value == 'test':
            self.testing_phase = True
        else:
            self.testing_phase = False

    def forward(self, input_tensor):
        """
        前向传播：根据阶段决定是否丢弃神经元
        """
        if not self.testing_phase:
            self.mask = (np.random.rand(*input_tensor.shape) < self.probability)
            return (input_tensor * self.mask) / self.probability

        else:
            return input_tensor

    def backward(self, error_tensor):
        return (error_tensor * self.mask) / self.probability