import numpy as np

from Layers.Base import BaseLayer
from Layers.Helpers import compute_bn_gradients


class BatchNormalization(BaseLayer):
    def __init__(self, channels):
        super().__init__()
        self.channels = channels
        self.trainable = True

        # 初始化权重 gamma 和偏置 beta
        self.weights = None
        self.bias = None
        self.initialize()

        # 优化器
        self.optimizer = None
        self.bias_optimizer = None

        # 阶段标志 (训练/测试)
        self.testing_phase = False

        # 移动平均 (Moving Average) 相关
        self.moving_mean = None
        self.moving_var = None
        self.alpha = 0.8  # 移动平均系数，通常在 0.8 到 0.9 之间

        # 缓存用于反向传播
        self.input_tensor = None
        self.x_hat = None
        self.mean = None
        self.var = None
        self.eps = 1e-10

    @property
    def phase(self):
        # 这是一个内部使用的 getter，虽然 NeuralNetwork 暂时没用到，但保持对称
        return 'test' if self.testing_phase else 'train'

    @phase.setter
    def phase(self, value):
        # 核心逻辑：将 'test'/'train' 字符串 转换为 内部的布尔开关
        if value == 'test':
            self.testing_phase = True
        else:
            self.testing_phase = False

    def initialize(self, weights_initializer=None, bias_initializer=None):
        # 按照要求：忽略传入的初始化器，gamma 设为 1，beta 设为 0
        self.weights = np.ones(self.channels)
        self.bias = np.zeros(self.channels)

    def reformat(self, tensor):
        """
        核心逻辑：在 4D (B, C, H, W) 和 2D (B*H*W, C) 之间转换
        """
        if len(tensor.shape) == 4:
            # 4D -> 2D
            # (B, C, H, W) -> (B, H, W, C) -> (B*H*W, C)
            B, C, H, W = tensor.shape
            reformatted = tensor.transpose(0, 2, 3, 1).reshape(-1, C)
        else:
            # 2D -> 4D (需要注意：这需要你在 forward 中保存原始 H, W)
            # 这里简化逻辑，通常根据之前 forward 存的 shape 还原
            B, H, W, C = self.original_shape[0], self.original_shape[2], self.original_shape[3], self.channels
            reformatted = tensor.reshape(B, H, W, C).transpose(0, 3, 1, 2)
        return reformatted

    def forward(self, input_tensor):
        self.original_shape = input_tensor.shape

        # 如果是卷积层输入 (4D)，进行重排
        if len(input_tensor.shape) == 4:
            x = self.reformat(input_tensor)
        else:
            x = input_tensor

        self.input_tensor = x  # 缓存 2D 版本

        if not self.testing_phase:
            # --- 训练阶段 ---
            self.mean = np.mean(x, axis=0)
            self.var = np.var(x, axis=0)

            # 更新移动平均
            if self.moving_mean is None:
                # 第一次训练，直接用当前 batch 的均值和方差初始化
                self.moving_mean = self.mean
                self.moving_var = self.var
            else:
                self.moving_mean = self.alpha * self.moving_mean + (1 - self.alpha) * self.mean
                self.moving_var = self.alpha * self.moving_var + (1 - self.alpha) * self.var

            curr_mean = self.mean
            curr_var = self.var
        else:
            # --- 测试阶段 ---
            curr_mean = self.moving_mean
            curr_var = self.moving_var

        # 标准化 (Normalization)
        self.x_hat = (x - curr_mean) / np.sqrt(curr_var + self.eps)

        # 缩放与平移 (Scale and Shift)
        output = self.weights * self.x_hat + self.bias

        # 如果输入是 4D，将其还原回 4D
        if len(self.original_shape) == 4:
            return self.reformat(output)
        return output

    def backward(self, error_tensor):
        # 统一转为 2D 处理梯度
        if len(error_tensor.shape) == 4:
            error_tensor_2d = self.reformat(error_tensor)
        else:
            error_tensor_2d = error_tensor

        # 1. 计算针对参数 gamma 和 beta 的梯度
        # grad_gamma = sum(error * x_hat)
        self.gradient_weights = np.sum(error_tensor_2d * self.x_hat, axis=0)
        # grad_beta = sum(error)
        self.gradient_bias = np.sum(error_tensor_2d, axis=0)

        # 2. 调用 Helpers 计算针对输入的梯度
        grad_input = compute_bn_gradients(error_tensor_2d, self.input_tensor, self.weights, self.mean, self.var)

        # 3. 如果有优化器，更新参数
        if self.optimizer:
            self.weights = self.optimizer.calculate_update(self.weights, self.gradient_weights)
        if self.bias_optimizer:
            self.bias = self.bias_optimizer.calculate_update(self.bias, self.gradient_bias)

        # 4. 还原维度
        if len(self.original_shape) == 4:
            return self.reformat(grad_input)
        return grad_input